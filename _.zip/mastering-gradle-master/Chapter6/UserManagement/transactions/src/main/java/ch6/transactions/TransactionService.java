package ch6.transactions;

class TransactionService {
	public static void main(String[] args) {
		System.out.println("This is transaction service");
	}
}
