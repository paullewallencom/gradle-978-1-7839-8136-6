package ch6.profile;

class ProfileService {
	public static void main(String[] args) {
		System.out.println("This is profile service");
	}
}
