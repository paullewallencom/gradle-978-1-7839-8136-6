package ch6.login;

class LoginService {
	public static void main(String[] args) {
		System.out.println("This is login service");
	}
}
