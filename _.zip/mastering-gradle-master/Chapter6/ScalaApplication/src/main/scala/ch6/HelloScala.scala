package ch6

object HelloScala {
    def main(args: Array[String]) {
      println("Hello, Scala...")
    }
}
