package ch4.custom.plugin

class FilePluginRootExtension {
	
	def sourceFile
	def destinationFile

}
