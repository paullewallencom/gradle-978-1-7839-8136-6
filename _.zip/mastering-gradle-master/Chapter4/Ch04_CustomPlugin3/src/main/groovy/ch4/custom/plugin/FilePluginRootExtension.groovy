package ch4.custom.plugin

class FilePluginRootExtension {
	
	def sourceFile = "/home/tmp"
	def destinationFile

}
